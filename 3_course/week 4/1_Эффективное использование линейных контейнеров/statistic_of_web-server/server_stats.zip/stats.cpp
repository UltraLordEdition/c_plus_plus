#include "stats.h"

using namespace std;

Stats::Stats() {
}

void Stats::AddMethod(string_view method) {
    try {
        ++method_.at(method);
    }
    catch (const exception& ex) {
        ++method_["UNKNOWN"];
    }
}

void Stats::AddUri(string_view uri) {
    try {
        ++uri_.at(uri);
    }
    catch (const exception& ex) {
        ++uri_["unknown"];
    }
}

const map<string_view, int>& Stats::GetMethodStats() const {
    return method_;
}

const map<string_view, int>& Stats::GetUriStats() const {
    return uri_;
}

HttpRequest ParseRequest(string_view line) {
    HttpRequest htl;
    size_t pos = 0u;

    while (line.front() == ' ') {
        line.remove_prefix(0u + 1u);
    }

    pos = line.find(' ', 0u);
    htl.method = line.substr(0, pos);
    line.remove_prefix(pos + 1u);

    pos = line.find(' ', 0u);
    htl.uri = line.substr(0, pos);
    line.remove_prefix(pos + 1u);

    htl.protocol = line.substr(0u, line.npos);
    return htl;
}

#include "search_server.h"
#include "iterator_range.h"
#include "profile.h"

#include <algorithm>
#include <iterator>
#include <sstream>
#include <iostream>
#include <numeric>
#include <set>

vector<string> SplitIntoWords(const string& line) {
  istringstream words_input(line);
  return {istream_iterator<string>(words_input), istream_iterator<string>()};
}

SearchServer::SearchServer(istream& document_input) {
  UpdateDocumentBase(document_input);
}

void SearchServer::UpdateDocumentBase(istream& document_input) {
  InvertedIndex new_index;
  
  for (string current_document; getline(document_input, current_document); ) {
    new_index.Add(move(current_document));
  }

  index = move(new_index);
}

void SearchServer::AddQueriesStream(istream& query_input, ostream& search_results_output) {
  // ������� ������ �� ������� �����, ��� �� ���� ��� �������� ��� ���� ������
  vector<pair<size_t, size_t>> docid_count(index.GetSizeIndex());
  for (string current_query; getline(query_input, current_query);) {
    const auto words = SplitIntoWords(move(current_query));
    docid_count.assign(index.GetSizeIndex(), { 0,0 });
    for (const auto& word : words) {
      for (const auto& [docid, count] : index.Lookup(word)) {
        docid_count[docid].first = docid;
        docid_count[docid].second += count;
      }
    }
    partial_sort(
      begin(docid_count),
      begin(docid_count) + 5u,
      end(docid_count),
      [](pair<int64_t, int64_t> lhs, pair<int64_t, int64_t> rhs) {
        int64_t lhs_docid = lhs.first;
        auto lhs_hit_count = lhs.second;
        int64_t rhs_docid = rhs.first;
        auto rhs_hit_count = rhs.second;
        return make_pair(lhs_hit_count, -lhs_docid) > make_pair(rhs_hit_count, -rhs_docid);
      }
    );
    vector<pair<size_t, size_t>> result;
    result.reserve(5);
    for (auto it = begin(docid_count); it != begin(docid_count) + 5u; ++it) {
      if ((it->first == 0) && (it->second == 0)) {
      }
      else {
        result.push_back(move(*it));
      }
    }
    search_results_output << current_query << ':';
    for (auto[docid, hitcount] : Head(result, 5)) {
      search_results_output << " {"
          << "docid: " << docid << ", "
          << "hitcount: " << hitcount << '}';
    } 
    search_results_output << endl;      
     
  }
}

void InvertedIndex::Add(const string& document) { 
  docs.push_back(document);
  const size_t docid = docs.size() - 1;
  
  for (const auto& word : SplitIntoWords(document)) {
      auto it = index.find(word);
      
      if (it == index.end()) {
          index.insert({ word, {{docid, 1}} }).first;
      }
      else if (it->second.back().first != docid) {
          it->second.push_back({ docid, 1 });
      }
      else {
          it->second.back().second++;
      }
  }
}

const vector<pair<size_t, size_t>>& InvertedIndex::Lookup(const string& word) const {
  static const vector<pair<size_t, size_t>> v;
  if (auto it = index.find(word); it != index.end()) {
      return it->second;
  } else {
    return v/*{}*/;
  }
}
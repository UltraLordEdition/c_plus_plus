#include "search_server.h"
#include "parse.h"
#include "test_runner.h"
#include "profile.h"

#include <algorithm>
#include <iterator>
#include <map>
#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <random>
#include <thread>
using namespace std;

void TestFunctionality(const vector<string>& docs, const vector<string>& queries, const vector<string>& expected ) {
  istringstream docs_input(Join('\n', docs));
  istringstream queries_input(Join('\n', queries));

  SearchServer srv;
  srv.UpdateDocumentBase(docs_input);
  
  ostringstream queries_output;
  srv.AddQueriesStream(queries_input, queries_output);

  const string result = queries_output.str();
  const auto lines = SplitBy(Strip(result), '\n');
  ASSERT_EQUAL(lines.size(), expected.size());
  for (size_t i = 0; i < lines.size(); ++i) {
    ASSERT_EQUAL(lines[i], expected[i]);
  }
}

void TestSerpFormat() {
  const vector<string> docs = {
    "london is the capital of great britain",
    "i am travelling down the river"
  };
  const vector<string> queries = {"london", "the"};
  const vector<string> expected = {
    "london: {docid: 0, hitcount: 1}",
    Join(' ', vector{
      "the:",
      "{docid: 0, hitcount: 1}",
      "{docid: 1, hitcount: 1}"
    })
  };

  TestFunctionality(docs, queries, expected);
}

void TestTop5() {
  const vector<string> docs = {
    "milk a",
    "milk b",
    "milk c",
    "milk d",
    "milk e",
    "milk f",
    "milk g",
    "water a",
    "water b",
    "fire and earth"
  };

  const vector<string> queries = {"milk", "water", "rock"};
  const vector<string> expected = {
    Join(' ', vector{
      "milk:",
      "{docid: 0, hitcount: 1}",
      "{docid: 1, hitcount: 1}",
      "{docid: 2, hitcount: 1}",
      "{docid: 3, hitcount: 1}",
      "{docid: 4, hitcount: 1}"
    }),
    Join(' ', vector{
      "water:",
      "{docid: 7, hitcount: 1}",
      "{docid: 8, hitcount: 1}",
    }),
    "rock:",
  };
  TestFunctionality(docs, queries, expected);
}

void TestHitcount() {
  const vector<string> docs = {
    "the river goes through the entire city there is a house near it",
    "the wall",
    "walle",
    "is is is is",
  };
  const vector<string> queries = {"the", "wall", "all", "is", "the is"};
  const vector<string> expected = {
    Join(' ', vector{
      "the:",
      "{docid: 0, hitcount: 2}",
      "{docid: 1, hitcount: 1}",
    }),
    "wall: {docid: 1, hitcount: 1}",
    "all:",
    Join(' ', vector{
      "is:",
      "{docid: 3, hitcount: 4}",
      "{docid: 0, hitcount: 1}",
    }),
    Join(' ', vector{
      "the is:",
      "{docid: 3, hitcount: 4}",
      "{docid: 0, hitcount: 3}",
      "{docid: 1, hitcount: 1}",
    }),
  };
  TestFunctionality(docs, queries, expected);
}

void TestRanking() {
  const vector<string> docs = {
    "london is the capital of great britain",
    "paris is the capital of france",
    "berlin is the capital of germany",
    "rome is the capital of italy",
    "madrid is the capital of spain",
    "lisboa is the capital of portugal",
    "bern is the capital of switzerland",
    "moscow is the capital of russia",
    "kiev is the capital of ukraine",
    "minsk is the capital of belarus",
    "astana is the capital of kazakhstan",
    "beijing is the capital of china",
    "tokyo is the capital of japan",
    "bangkok is the capital of thailand",
    "welcome to moscow the capital of russia the third rome",
    "amsterdam is the capital of netherlands",
    "helsinki is the capital of finland",
    "oslo is the capital of norway",
    "stockgolm is the capital of sweden",
    "riga is the capital of latvia",
    "tallin is the capital of estonia",
    "warsaw is the capital of poland",
  };

  const vector<string> queries = {"moscow is the capital of russia"};
  const vector<string> expected = {
    Join(' ', vector{
      "moscow is the capital of russia:",
      "{docid: 7, hitcount: 6}",
      "{docid: 14, hitcount: 6}",
      "{docid: 0, hitcount: 4}",
      "{docid: 1, hitcount: 4}",
      "{docid: 2, hitcount: 4}",
    })
  };
  TestFunctionality(docs, queries, expected);
}

void TestBasicSearch() {
  const vector<string> docs = {
    "we are ready to go",
    "come on everybody shake you hands",
    "i love this game",
    "just like exception safety is not about writing try catch everywhere in your code move semantics are not about typing double ampersand everywhere in your code",
    "daddy daddy daddy dad dad dad",
    "tell me the meaning of being lonely",
    "just keep track of it",
    "how hard could it be",
    "it is going to be legen wait for it dary legendary",
    "we dont need no education"
  };

  const vector<string> queries = {
    "we need some help",
    "it",
    "i love this game",
    "tell me why",
    "dislike",
    "about"
  };

  const vector<string> expected = {
    Join(' ', vector{
      "we need some help:",
      "{docid: 9, hitcount: 2}",
      "{docid: 0, hitcount: 1}"
    }),
    Join(' ', vector{
      "it:",
      "{docid: 8, hitcount: 2}",
      "{docid: 6, hitcount: 1}",
      "{docid: 7, hitcount: 1}",
    }),
    "i love this game: {docid: 2, hitcount: 4}",
    "tell me why: {docid: 5, hitcount: 2}",
    "dislike:",
    "about: {docid: 3, hitcount: 2}",
  };
  TestFunctionality(docs, queries, expected);
}

void TestCase10Request16() {
    const vector<string> docs = {
    "twothree",
    "five",
    "five",
    "six",
    "one",
    "four",
    "one",
    "twothree",
    "four",
    "one",
    "one",
    "twothree",
    "four",
    "five",
    "six",
    "one twothree",
    "one four",
    "one five",
    "one six",
    "twothree four",
    "twothree five",
    "twothree six",
    "four five",
    "four six",
    "five six",
    "one twothree four",
    "one twothree five",
    "one twothree six",
    "one four five",
    "one four six",
    "one five six"
    "twothree four five",
    "twothree four six",
    "twothree five six",
    "four five six",
    "one twothree four five",
    "one twothree four six",
    "one twothree five six",
    "one four five six",
    "twothree four five six",
    "one twothree four five six"
    };

    const vector<string> queries = {
      "one",
      "twothree",
      "one twothree five"
    };

    const vector<string> expected = {
      Join(' ', vector{
        "one:",
        "{docid: 4, hitcount: 1}",
        "{docid: 6, hitcount: 1}",
        "{docid: 9, hitcount: 1}",
        "{docid: 10, hitcount: 1}",
        "{docid: 15, hitcount: 1}"
      }),
      Join(' ', vector{
      "twothree:",
      "{docid: 0, hitcount: 1}",
      "{docid: 7, hitcount: 1}",
      "{docid: 11, hitcount: 1}",
      "{docid: 15, hitcount: 1}",
      "{docid: 19, hitcount: 1}"
    }),
    Join(' ', vector{
      "one twothree five:",
      "{docid: 26, hitcount: 3}",
      "{docid: 30, hitcount: 3}",
      "{docid: 34, hitcount: 3}",
      "{docid: 36, hitcount: 3}",
      "{docid: 39, hitcount: 3}"
    })
    };
    TestFunctionality(docs, queries, expected);
}

vector<string> getDocs() {
    LOG_DURATION("getDocs()");
    const int SIZE = 50'000'000;
    string text(SIZE, 'a');
    vector<string> str;
    for (int i = 0; i < SIZE; i += 5) {
        text[i] = ' ';
    }
    for (int i = 0; i < SIZE; i += 1000) {
        if (i != 0) {
            text[i] = '\n';
        }
    }
    stringstream ss;
    ss << text;
    for (string line; getline(ss, line); ) {
        str.push_back(move(line));
    }
    str[0] = "one";
    str[str.size()-1u] = "two";
    return str;
}

// ������� ����������� ����
void TestBenchmark() {
    LOG_DURATION("TestBenchmark()");

    const vector<string> queries = {
      "one",
      "two"
    };

    const vector<string> expected = {
      Join(' ', vector{
        "one:",
        "{docid: 0, hitcount: 1}",
      }),
      Join(' ', vector{
        "two:",
        "{docid: 49999, hitcount: 1}",
      })
    };

    TestFunctionality(getDocs(), queries, expected);
}

int main() {
  TestRunner tr;
  RUN_TEST(tr, TestSerpFormat);
  RUN_TEST(tr, TestTop5);
  RUN_TEST(tr, TestHitcount);
  RUN_TEST(tr, TestRanking);
  RUN_TEST(tr, TestBasicSearch);
  RUN_TEST(tr, TestCase10Request16);
  //RUN_TEST(tr, TestBenchmark);
}
